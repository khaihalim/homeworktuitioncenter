public class StudentBatch{
    Student BatchStudent[]=new Student[8];
    static int Studentnum=0;
    
    String batchName;
    
    void addStud(Student c){
        BatchStudent[Studentnum++]=c;
    }
    
    static int getnumstud(){
        return Studentnum;
    }
}