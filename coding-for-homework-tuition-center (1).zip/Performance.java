public class Performance{
    Student stud;
    Tutor tutorlist;
    Float avgMarks;
    Float min;
    Float max;
    String tutorBg;
    
    
   
    public float calcMin(){
        return 0;
    }
    public float calcMax(){
        return 0;
    }
    
}