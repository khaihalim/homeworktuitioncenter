
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    
	    Tutor Ramli=new Tutor();
	    Ramli.name="Ramli";
	    Ramli.IC="2200-23-1133";
	    Ramli.address="Selangor";
	    Ramli.qualification="Degree";
	    Ramli.yearExp=3;
	    Ramli.date="04/01/2021";
	    Ramli.year=5;
	    
	    Tutor Minah=new Tutor();
	    Minah.name="Minah";
	    Minah.IC="2876-22-2356";
	    Minah.address="Selangor";
	    Minah.qualification="Degree";
	    Minah.yearExp=8;
	    Minah.date="04/05/2015";
	    Minah.year=10;
	    
	    Student Razak=new Student();
	    Razak.name="Razak";
	    Razak.IC="2345-33-4567";
	    Razak.address="Melaka";
	    Razak.addScore();
	    Razak.addScore();
	    Razak.assigntutor(Minah);
	    
	    Student Mimi=new Student();
	    Mimi.name="Mimi";
	    Mimi.IC="5510-45-1234";
	    Mimi.address="Pahang";
	    Mimi.addScore();
	    Mimi.addScore();
	    Mimi.assigntutor(Ramli);
	    
	    StudentBatch Batch02= new StudentBatch();
	    Batch02.batchName="Batch 2002";
	    Batch02.addStud(Razak);
	    
	    StudentBatch Batch04= new StudentBatch();
	    Batch04.batchName="Batch 2004";
	    Batch04.addStud(Mimi);
	    
	    TuitionCentre Mawar=new TuitionCentre();
	    Mawar.name="Mawar";
	    Mawar.address="Selangor";
	    Mawar.headMaster="Kirana";
	    Mawar.addTutor(Ramli);
	    Mawar.addBatch(Batch02);
	    Mawar.addBatch(Batch04);
	    
	    TuitionCentre Pintar=new TuitionCentre();
	    Pintar.name="Pintar";
	    Pintar.address="Melaka";
	    Pintar.headMaster="Azli";
	    Pintar.addTutor(Minah);
	    Pintar.addBatch(Batch02);
	    Pintar.addBatch(Batch04);
	    
	    float avg = 0;
        avg = Razak.calcAvg();
        System.out.println("Avg = " + avg);
        float avg = 0;
        avg = Mimi.calcAvg();
        System.out.println("Avg = " + avg);
        
        
        System.out.println("Min = " + Razak.calcMin());  
	    System.out.println("Min = " + Mimi.calcMin()); 
	    
	    System.out.println("Min = " + Razak.calcMin()); 
	    System.out.println("Min = " + Mimi.calcMin()); 
	    
		
	}
}
