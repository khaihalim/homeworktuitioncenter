public class Tutor{
    String name;
    String IC;
    String address;
    String qualification;
    int yearExp;
    String date;
    int year;
}