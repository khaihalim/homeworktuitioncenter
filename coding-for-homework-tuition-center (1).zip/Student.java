import java.util.Scanner;

public class Student{
    Scanner sc=new Scanner(System.in);
    String name;
    String IC;
    String address;
    int year;
    String schoolName;
    float listScore[]=new float[2];
    Tutor tutorName;
    
    void addScore(){
        System.out.println("Please enter Score: ");
        for(int i=0;i<2;i++){
            System.out.println("Score for subject"+(i+1)+ ":" );
            listScore[i]=sc.nextFloat();
            sum=sum+listScore[i];
        }
    }
     public float calcAvg(){
        avg=sum/2;
        return 0;
    }
    void assigntutor(Tutor v){
        tutorName=v;
    }
}
