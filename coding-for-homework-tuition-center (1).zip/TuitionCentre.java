public class TuitionCentre{
    String name;
    String address;
    String headMaster;
    Tutor tutorList[]=new Tutor[3];
    static int tutornum=0;
    StudentBatch batchList[]=new StudentBatch[3];
    static int batchnum=0;
    
    void addTutor(Tutor k){
        tutorList[tutornum++]=k;
    }
    void addBatch(StudentBatch z){
        batchList[batchnum++]=z;
    }
    
}