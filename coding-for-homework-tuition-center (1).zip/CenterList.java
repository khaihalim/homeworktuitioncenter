public class CenterList{
    TuitionCentre CenterList[]=new TuitionCentre[5];
    int currentCenter=0;
    
    void addCenter(TuitionCentre b){
        CenterList[currentCenter++]=b;
    }
    void deleteCenter(TuitionCentre b){
        for(int i=0;i<5;i++){
            if (CenterList[i]==b){
                CenterList[i]=null;
                System.out.print("The center has been deleted");
            }
        }
    }
}